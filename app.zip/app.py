import cv2
from ultralytics import YOLO
from flask import Flask, Response, render_template, request
import tempfile
import os
from datetime import datetime

## Flask APPLICATION
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'  # NOT inside static now
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)



# Load the YOLOv8 model
model = YOLO(r"C:\Users\Thanusha\Downloads\EOC-MFC\last.pt")

# Flag to indicate if the script should terminate
terminate_flag = False

# Ensure static/videos directory exists
VIDEO_FOLDER = os.path.join("static", "videos")
os.makedirs(VIDEO_FOLDER, exist_ok=True)

# Define a generator function to stream video frames to the web page
def generate(file_path):
    global terminate_flag

    if file_path == "camera":
        cap = cv2.VideoCapture(0)

        # Get the actual resolution from webcam
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        # Create a unique filename for output
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        video_filename = f"output_{timestamp}.mp4"
        video_path = os.path.join(VIDEO_FOLDER, video_filename)
        print(f"🔴 Recording video to: {video_path}")

        # Set up video writer with dynamic resolution
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = cv2.VideoWriter(video_path, fourcc, 20.0, (width, height))
    else:
        cap = cv2.VideoCapture(file_path)
        out = None  # No recording for uploaded file

    while cap.isOpened():
        success, frame = cap.read()

        if success:
            # Run YOLOv8 inference on the frame
            results = model.predict(frame)
            annotated_frame = results[0].plot()

            # Save to video if using webcam
            if file_path == "camera" and out:
                out.write(annotated_frame)

            # Encode the frame as JPEG
            ret, jpeg = cv2.imencode('.jpg', annotated_frame)
            if not ret:
                break

            # Yield the JPEG data to Flask
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + jpeg.tobytes() + b'\r\n')

            if cv2.waitKey(1) == 27 or terminate_flag:
                break
        else:
            break

    cap.release()
    if out:
        out.release()
    cv2.destroyAllWindows()
    terminate_flag = False  # Reset the flag

# Define a route to serve the video stream
@app.route('/video_feed')
def video_feed():
    file_path = request.args.get('file')
    if not file_path:
        return "No file specified", 400
    return Response(generate(file_path),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

# Define a route to serve the HTML page with the file upload form
@app.route('/', methods=['GET', 'POST'])
def index():
    global terminate_flag
    file_path = None

    if request.method == 'POST':
        if request.form.get("camera") == "true":
            file_path = "camera"
        elif 'file' in request.files:
            file = request.files['file']
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(file_path)

    return render_template('index.html', file_path=file_path)

@app.route('/stop', methods=['POST'])
def stop():
    global terminate_flag
    terminate_flag = True
    return "Process has been Terminated"

if __name__ == '__main__':
    app.run(debug=True)

